import "./footer.css";
export function Footer() {
  return (
    <footer className="headerCont footer">
      <p>Copylefts forever</p>
      <p>All rights REVERSED</p>
    </footer>
  );
}
