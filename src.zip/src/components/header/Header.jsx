import "./header.css";
export function Header() {
  return (
    <header className="headerCont">
      <p>Justin R.E.A.C.T. training tasks:</p>
    </header>
  );
}
